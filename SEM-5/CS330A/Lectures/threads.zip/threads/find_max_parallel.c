#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<string.h>
#include<math.h>
#include<assert.h>
#include<pthread.h>

#define SEED 0x74587
#define MAX_THREADS 64
#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <# of elements> <# of threads> \n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

#define TDIFF(start, end) ((end.tv_sec - start.tv_sec) * 1000000UL + (end.tv_usec - start.tv_usec))

struct thread_param{
                       pthread_t tid;
                       int *array;
                       int size;
                       double max;
                       int max_index;
};

double function(double element)
{
    return (sqrt(element) * sin(element));
}

void* find_max(void *arg)
{
     struct thread_param *param = (struct thread_param *) arg;
     int ctr;

     param->max = function(param->array[0]);
     param->max_index = 0;

     for(ctr=1; ctr < param->size; ++ctr){
           double result = function(param->array[ctr]);
           if(result > param->max){
                param->max = result;
                param->max_index = ctr;
           }
     }          
     return NULL;
}

int main(int argc, char **argv)
{
  struct thread_param *params;
  struct timeval start, end;
  int *a, *ptr;
  int num_elements, ctr, num_threads, per_thread, residue, max_index;
  double max = 0.0;

  if(argc !=3)
           USAGE_EXIT("not enough parameters");

  num_elements = atoi(argv[1]);
  if(num_elements <=0)
          USAGE_EXIT("invalid num elements");
  
  num_threads = atoi(argv[2]);
  if(num_threads <=0 || num_threads > MAX_THREADS){
          USAGE_EXIT("invalid num of threads");
  }

  per_thread = num_elements / num_threads;
  residue = num_elements % num_threads;   /*Have to distribute*/

  if(per_thread <= 0)
          USAGE_EXIT("invalid num of elements to threads");

  /* Parameters seems to be alright. Lets start our business*/

  a = malloc(num_elements * sizeof(int));
  if(!a){
          USAGE_EXIT("invalid num elements, not enough memory");
  }
  srand(SEED);
  for(ctr=0; ctr<num_elements; ++ctr)
        a[ctr] = rand();


  /*Allocate thread specific parameters*/
  params = malloc(num_threads * sizeof(struct thread_param));
  bzero(params, num_threads * sizeof(struct thread_param));

  ptr = a;
  gettimeofday(&start, NULL);

  for(ctr=0; ctr < num_threads; ++ctr){
        struct thread_param *param = params + ctr;
        param->size = per_thread;

        if(residue){   
              param->size++;
              --residue;
        }
        param->array = ptr;
        ptr += param->size;  
        
        if(pthread_create(&param->tid, NULL, find_max, param) != 0){
              perror("pthread_create");
              exit(-1);
        }
 
  }
  assert((ptr - a) == num_elements); 
  num_elements = 0;
   
  for(ctr=0; ctr < num_threads; ++ctr){
        struct thread_param *param = params + ctr;
        pthread_join(param->tid, NULL);
        if(ctr == 0 || (ctr > 0 && param->max > max)){
             max = param->max;    
             max_index = num_elements + param->max_index;
        }
        num_elements += param->size;
        gettimeofday(&end, NULL);
  }
     
  gettimeofday(&end, NULL);
  printf("Time taken = %ld microsecs\n", TDIFF(start, end));
  printf("Max = %.2f @index %d\n", max, max_index);
  free(a);
  free(params);
}
